package Ai; 

import java.util.*;

public class Tree<Game> {
    private Node<Game> root;

    public Tree(Game rootData) {
        root = new Node<Game>();
        root.data = rootData;
        root.children = new ArrayList<Node<Game>>();
    }

    public static class Node<Game> {
        private Game data;
        private Node<Game> parent;
        private List<Node<Game>> children;
        private boolean exploredChildren = false; 
        
        public Node<Game>(Game data){
        	this.data = data; 
        }
    }
    
    public int minimax(Node<Game> position, int depth, int a, int b, boolean whitePlayer) {
    	if(!position.exploredChildren) {
    		retrieveChildren(position, whitePlayer); 
    		position.exploredChildren = true; 
    	}
    	if(depth == 0 || position.children.size() == 0) {
    		//return score of node #TODO Discuss scoring
    		
    		return -1; 
    	}
    	if(whitePlayer) {
    		int maxEval = -99999999;
    		for(Node<Game> child: position.children ) {
    			int eval = minimax(child, depth-1, a, b, false);
    			maxEval = Math.max(maxEval, eval); 
    			a = Math.max(a, eval);
    			if(b <= a)
    					break;
    		}
    		return maxEval; 
    	}else {
    		int minEval = 99999999;
    		for(Node<Game> child: position.children ) {
    			int eval = minimax(child, depth-1, a, b, false);
    			minEval = Math.min(minEval, eval); 
    			a = Math.max(a, eval);
    			if(b <= a)
    					break;
    		}
    		return minEval; 
    	}
    }
    
    public boolean retrieveChildren(Node<Game> node, boolean whitePlayer) {
    	Game gameState = node.data; 
    	int player = -1; // assume black
    	if(whitePlayer) { // if white change color
    		player = 1; 
    	}
    	for(int i = 0; i < 8; i++) {
    		for(int j = 0; j <8; j++)
    			if(gameState.checkMoveLegality(i, j, player)) {
    				// add it to children
    				
    			}
    				
    	}
    	return false; 
    }
}